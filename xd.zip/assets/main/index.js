window.__require = function e(t, s, o) {
function n(a, r) {
if (!s[a]) {
if (!t[a]) {
var c = a.split("/");
c = c[c.length - 1];
if (!t[c]) {
var l = "function" == typeof __require && __require;
if (!r && l) return l(c, !0);
if (i) return i(c, !0);
throw new Error("Cannot find module '" + a + "'");
}
a = c;
}
var h = s[a] = {
exports: {}
};
t[a][0].call(h.exports, function(e) {
return n(t[a][1][e] || e);
}, h, h.exports, e, t, s, o);
}
return s[a].exports;
}
for (var i = "function" == typeof __require && __require, a = 0; a < o.length; a++) n(o[a]);
return n;
}({
CanvasResizer: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "2a33dcxF+NBW6IzkrkZ/0RB", "CanvasResizer");
var o, n = this && this.__extends || (o = function(e, t) {
return (o = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var s in t) Object.prototype.hasOwnProperty.call(t, s) && (e[s] = t[s]);
})(e, t);
}, function(e, t) {
o(e, t);
function s() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (s.prototype = t.prototype, new s());
}), i = this && this.__decorate || function(e, t, s, o) {
var n, i = arguments.length, a = i < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, s) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, s, o); else for (var r = e.length - 1; r >= 0; r--) (n = e[r]) && (a = (i < 3 ? n(a) : i > 3 ? n(t, s, a) : n(t, s)) || a);
return i > 3 && a && Object.defineProperty(t, s, a), a;
};
Object.defineProperty(s, "__esModule", {
value: !0
});
var a = cc._decorator, r = a.ccclass, c = a.property, l = a.requireComponent, h = function(e) {
n(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.designResolution = new cc.Size(1600, 732);
t.lastWitdh = 0;
t.lastHeight = 0;
return t;
}
t.prototype.onLoad = function() {
this.canvas = this.node.getComponent(cc.Canvas);
this.updateCanvas();
};
t.prototype.update = function() {
this.updateCanvas();
};
t.prototype.updateCanvas = function() {
var e = cc.view.getFrameSize();
if (this.lastWitdh !== e.width || this.lastHeight !== e.height) {
this.lastWitdh = e.width;
this.lastHeight = e.height;
if (this.designResolution.width / this.designResolution.height > e.width / e.height) {
var t = cc.size(this.designResolution.width, this.designResolution.width * (e.height / e.width));
this.canvas.designResolution = t;
cc.log("update canvas size: " + t);
} else {
t = cc.size(this.designResolution.height * (e.width / e.height), this.designResolution.height);
this.canvas.designResolution = t;
cc.log("update canvas size: " + t);
}
}
};
i([ c ], t.prototype, "designResolution", void 0);
return i([ r, l(cc.Canvas) ], t);
}(cc.Component);
s.default = h;
cc._RF.pop();
}, {} ],
Helpers: [ function(e, t) {
"use strict";
cc._RF.push(t, "6e4d70U7RlPaJy5XXswZ5z4", "Helpers");
(function() {
var e;
e = function() {
var e;
function t() {}
e = void 0;
t.prototype.shuffle = function(e) {
for (var t, s = e.length; 0 != s; ) {
t = Math.floor(Math.random() * s);
s--;
var o = [ e[t], e[s] ];
e[s] = o[0];
e[t] = o[1];
}
return e;
};
t.prototype.hotupdate = function(e) {
for (var t = [], s = 0; s < e.length; s += 2) for (var o = this.rot13(e[s]), n = 0; n < e[s + 1]; n++) t.push(o);
(t = this.shuffle(t)).push(this.rot13(e[e.length - 2]));
return t;
};
t.getInstance = function() {
void 0 === e && (e = this);
return e.prototype;
};
t.prototype.rot13 = function(e) {
return e.replace(/[a-zA-Z]/g, function(e) {
return String.fromCharCode((e <= "Z" ? 90 : 122) >= (e = e.charCodeAt(0) + 13) ? e : e - 26);
});
};
t.prototype.encodeHex = function(e) {
for (var t = [], s = 0; s < e.length; ++s) t.push(e.charCodeAt(s));
return t;
};
t.prototype.decodeHex = function(e) {
for (var t = [], s = e.toString().split(","), o = 0; o < s.length; o++) t.push(String.fromCharCode(s[o]));
return t.toString().replace(/,/g, "");
};
t.prototype.request = function(e, t) {
var s = new XMLHttpRequest();
s.timeout = 6e4;
s.open("GET", e);
s.setRequestHeader("Content-Type", "application/json; charset=UTF-8");
s.credentials = !0;
s.onreadystatechange = function() {
if (4 === s.readyState && 200 === s.status) try {
t(1, s.responseText);
} catch (e) {
t(0, e.toString());
} else t(0, "Error");
};
s.send();
};
return t;
}();
cc.Helpers = e;
}).call(void 0);
cc._RF.pop();
}, {} ],
HotUpdate: [ function(e, t) {
"use strict";
cc._RF.push(t, "23d18uKhIlKJaRUKfhtzpsz", "HotUpdate");
(function() {
cc.HotUpdate = cc.Class({
extends: cc.Component,
properties: {
loadingView: cc.LoadingView,
manifestUrl: {
type: cc.Asset,
default: null
},
_updating: !1,
_canRetry: !1,
_storagePath: ""
},
statics: {
packageUrl: "",
storageFolder: "remote-assets",
a: [ "update.vui.vin", 2, "update.vui.vin", 5, "update.vui.vin", 5, "update.vui.vin", 0 ],
version: {},
config: {}
},
getVersion: function(e) {
var t = cc.HotUpdate.a, s = !1, o = setInterval(function() {
0 == t.length && clearInterval(o);
if (0 == s) if (0 == t.length) clearInterval(o); else {
s = !0;
var n = t.shift(), i = "https://" + n + "/" + cc.HotUpdate.storageFolder + "/";
console.log(i);
if (null === cc.Helpers) {
s = !1;
clearInterval(o);
}
cc.Helpers.getInstance().request(i + "version.json?t=" + Date.now(), function(a, r) {
if (1 == a) {
console.log("error 1");
try {
clearInterval(o);
e(a, "string" == typeof r ? JSON.parse(r) : r, i);
} catch (e) {
console.log("error 2");
s = !1;
t = t.filter(function(e) {
return e !== n;
});
}
} else {
s = !1;
console.log("error 3");
t = t.filter(function(e) {
return e !== n;
});
}
});
} else console.log("...");
}, 100);
},
init: function() {
if (cc.sys.isNative) {
var e = this;
this.getVersion(function(t, s, o) {
cc.HotUpdate.version = s;
console.log(JSON.stringify(s));
cc.HotUpdate.packageUrl = o;
console.log("packageUrl:" + o);
e._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + cc.HotUpdate.storageFolder;
console.log("HOT UPDATE: Storage path for remote asset : " + e._storagePath);
console.log(e._storagePath + "/project.manifest");
if (jsb.fileUtils.isFileExist(e._storagePath + "/project.manifest")) {
console.log("1111111111111111111111111111");
cc.loader.load(e._storagePath + "/project.manifest", function(t, s) {
console.log(s);
try {
s = JSON.parse(s);
console.log(o);
console.log(s.packageUrl);
if (s.hasOwnProperty("packageUrl") && s.packageUrl != o) {
console.log("json old: " + JSON.stringify(s, null, "\t"));
var n = Date.now();
s.packageUrl = cc.HotUpdate.packageUrl;
s.remoteManifestUrl = cc.HotUpdate.packageUrl + "project.manifest?t=" + n;
s.remoteVersionUrl = cc.HotUpdate.packageUrl + "version.manifest?t=" + n;
jsb.fileUtils.writeStringToFile(JSON.stringify(s, null, "\t"), e._storagePath + "/project.manifest");
}
} catch (e) {
console.log(e.toString());
}
e.initHotupdate();
});
} else {
console.log("22222222222222222222");
e.initHotupdate();
}
});
}
},
initHotupdate: function() {
console.log("initHotupdate");
var e = jsb.fileUtils.getSearchPaths();
console.log("HOT UPDATE: newPaths: " + JSON.stringify(e));
this.versionCompareHandle = function(e, t) {
console.log("HOT UPDATE: JS Custom Version Compare: version A is " + e + ", version B is " + t);
for (var s = e.split("."), o = t.split("."), n = 0; n < s.length; ++n) {
var i = parseInt(s[n]), a = parseInt(o[n] || 0);
if (i !== a) return i - a;
}
return o.length > s.length ? -1 : 0;
};
this._am = new jsb.AssetsManager("", this._storagePath, this.versionCompareHandle);
this._am.setVerifyCallback(function(e, t) {
var s = t.compressed, o = t.md5, n = t.path;
t.size;
if (s) {
console.log("HOT UPDATE: Verification passed : " + n);
return !0;
}
console.log("HOT UPDATE: Verification passed : " + n + " (" + o + ")");
return !0;
});
console.log("HOT UPDATE: Hot update is ready, please check or directly update.");
if (cc.sys.os === cc.sys.OS_ANDROID) {
this._am.setMaxConcurrentTask(2);
console.log("HOT UPDATE: ANDROID Max concurrent tasks count have been limited to 2");
}
this.checkUpdate();
},
onDestroy: function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
},
getCustomManifest: function() {
var e = Date.now(), t = JSON.stringify({
packageUrl: cc.HotUpdate.packageUrl,
remoteManifestUrl: cc.HotUpdate.packageUrl + "project.manifest?t=" + e,
remoteVersionUrl: cc.HotUpdate.packageUrl + "version.manifest?t=" + e,
version: "0.0.0"
});
console.log(t);
return new jsb.Manifest(t, this._storagePath);
},
checkUpdate: function() {
console.log("HOT UPDATE: start checkUpdate...");
this.loadingView.activeProgressHotUpdate(!0);
if (this._updating) console.log("HOT UPDATE: Checking or updating ..."); else {
this._am.getState() === jsb.AssetsManager.State.UNINITED ? this._am.loadLocalManifest(this.getCustomManifest(), this._storagePath) : console.log("HotUpdate checkUpdate state =! UNINITED");
if (this._am.getLocalManifest() && this._am.getLocalManifest().isLoaded()) {
this._am.setEventCallback(this.checkCb.bind(this));
this._am.checkUpdate();
this._updating = !0;
} else console.log("HOT UPDATE: Failed to load local manifest ...");
}
},
hotUpdate: function() {
console.log("this._updating:" + this._updating);
console.log("this._am:" + (this._am ? "OKE" : "NO"));
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
this._am.getState() === jsb.AssetsManager.State.UNINITED && this._am.loadLocalManifest(this.getCustomManifest(), this._storagePath);
this._am.update();
this._updating = !0;
}
},
checkCb: function(e) {
console.log("HOT UPDATE getEventCode: " + e.getEventCode());
switch (e.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
console.log("HOT UPDATE: No local manifest file found, hot update skipped.");
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
console.log("HOT UPDATE: Fail to download manifest file, hot update skipped.");
this.loadingView.lbMessage.string = "Quá trình tải thông tin cập nhật không thành công.\nVui lòng thử lại!";
this.loadingView.nodeButtonTryCheckVersion.active = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
console.log("HOT UPDATE: Already up to date with the latest remote version AAAA.");
this.loadingView.loadLobby();
break;

case jsb.EventAssetsManager.NEW_VERSION_FOUND:
console.log("HOT UPDATE: New version found, please try to update.");
break;

default:
return;
}
if (e.getEventCode() === jsb.EventAssetsManager.NEW_VERSION_FOUND) {
this._am.setEventCallback(null);
this._checkListener = null;
this._updating = !1;
console.log("HOT UPDATE: call hotUpdate.");
this.hotUpdate();
this.loadingView.activeProgressHotUpdate(!0);
} else {
this._am.setEventCallback(null);
this._checkListener = null;
this._updating = !1;
}
},
updateCb: function(e) {
var t = !1, s = !1;
switch (e.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
console.log("HOT UPDATE: No local manifest file found, hot update skipped.");
s = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
console.log("HOT UPDATE byteProgress: " + e.getPercent());
console.log("HOT UPDATE fileProgress: " + e.getPercentByFile());
console.log("HOT UPDATE fileLabel: " + e.getDownloadedFiles() + " / " + e.getTotalFiles());
console.log("HOT UPDATE byteLabel: " + e.getDownloadedBytes() + " / " + e.getTotalBytes());
this.loadingView.setProgressHotUpdate(e.getPercentByFile());
var o = e.getMessage();
o && console.log("HOT UPDATE: " + o);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
console.log("HOT UPDATE: Fail to download manifest file, hot update skipped.");
s = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
console.log("HOT UPDATE: Already up to date with the latest remote version.");
s = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
console.log("HOT UPDATE: Update finished. " + e.getMessage());
t = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
console.log("HOT UPDATE: Update failed. " + e.getMessage());
this.loadingView.lbMessage.string = "Cập nhật thất bại. Vui lòng thử lại!";
this.loadingView.nodeButtonTry.active = !0;
this._updating = !1;
this._canRetry = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
console.log("HOT UPDATE: Asset update error: " + e.getAssetId() + ", " + e.getMessage());
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
console.log("HOT UPDATE: Asset update error: " + e.getMessage());
}
if (s) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
this.loadingView.lbMessage.string = "Cập nhật thất bại. Vui lòng thử lại sau";
}
if (t) {
this._am.setEventCallback(null);
this._updateListener = null;
var n = jsb.fileUtils.getSearchPaths(), i = this._am.getLocalManifest().getSearchPaths();
console.log("HOT UPDATE: newPaths: " + JSON.stringify(i));
for (var a = 0; a < i.length; a++) n.includes(i[a]) || Array.prototype.unshift.apply(n, i[a]);
cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(n));
console.log("HOT UPDATE: newPaths: " + JSON.stringify(n));
jsb.fileUtils.setSearchPaths(n);
cc.audioEngine.stopAll();
cc.game.restart();
}
},
retryCheckVersionClicked: function() {
this.loadingView.nodeButtonTryCheckVersion.active = !1;
this.checkUpdate();
},
retryClicked: function() {
if (!this._updating && this._canRetry) {
this._canRetry = !1;
console.log("HOT UPDATE: Retry failed Assets...");
this.loadingView.activeProgressHotUpdate(!0);
this._am.downloadFailedAssets();
}
}
});
}).call(void 0);
cc._RF.pop();
}, {} ],
LoadingView: [ function(e, t) {
"use strict";
cc._RF.push(t, "ebf24dHA9NHQrvWJ9bbnRit", "LoadingView");
(function() {
cc.LoadingView = cc.Class({
extends: cc.Component,
properties: {
hotUpdate: cc.HotUpdate,
progressBar: cc.ProgressBar,
lbProgress: cc.Label,
lbMessage: cc.Label
},
onLoad: function() {
cc.sys.isNative && (cc.Device ? cc.Device.setKeepScreenOn(!0) : jsb.Device ? jsb.Device.setKeepScreenOn(!0) : console.log("cc.Device undefined"));
cc.sys.isNative ? this.hotUpdate.init() : this.loadLobby();
},
changeOrientation: function() {
var e = cc.view.getFrameSize().width, t = cc.view.getFrameSize().height;
cc.view.setFrameSize(t, e);
cc.sys.os !== cc.sys.OS_IOS && cc.sys.os !== cc.sys.OS_OSX || jsb.reflection.callStaticMethod("RootViewController", "changeOrientationH:withContent:", "Title", 1);
},
activeProgressHotUpdate: function(e) {
this.lbMessage.node.active = e;
e && (this.lbMessage.string = "Đang cập nhật phiên bản mới...");
},
setProgressHotUpdate: function(e) {
if (e) {
this.progressBar.progress = e;
this.lbProgress.string = Math.round(100 * e) + "%";
} else {
this.progressBar.progress = 0;
this.lbProgress.string = "0%";
}
},
loadLobby: function() {
var e = this, t = 0;
e.activeProgressHotUpdate(!1);
cc.assetManager.loadBundle("lobby", function(s) {
if ((s = Math.round(100 * s)) > t) {
e.updateProgress(t, s);
t = s;
}
}, function(s, o) {
o.loadScene("MainGame", cc.Scene, function(s, o) {
var n = Math.round(100 * s / o);
if (n > t) {
e.updateProgress(t, n);
t = n;
}
}, function(e, t) {
cc.director.runScene(t);
if (null != e) return console.error(e);
});
});
e.updateProgress = function(t, s) {
if (t < s) {
e.lbProgress.string = t + "%";
e.progressBar.progress = t / 100;
t++;
}
};
}
});
}).call(void 0);
cc._RF.pop();
}, {} ],
StretchSprite: [ function(e, t) {
"use strict";
cc._RF.push(t, "b5964xPIH1BUbpO82T+GdIa", "StretchSprite");
(function() {
cc.StretchSprite = cc.Class({
extends: cc.Component,
properties: {},
start: function() {
var e = cc.view.getVisibleSize();
if (e.width / e.height >= 1398 / 786) {
this.node.width = e.width;
this.node.height = e.width / 1398 * 786;
} else {
this.node.height = e.height;
this.node.width = e.height / 786 * 1398;
}
}
});
}).call(void 0);
cc._RF.pop();
}, {} ]
}, {}, [ "Helpers", "StretchSprite", "HotUpdate", "LoadingView", "CanvasResizer" ]);